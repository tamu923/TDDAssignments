package com.yash.tddAssignments;

public class CheckNumbers {
	
	public String checkDigitMultiplication(int num) {
		
		int product = 1;
		 
        while (num != 0) {
            product = product * (num % 10);
            num = num / 10;
        }
 
		return String.valueOf(product);
		
	}

}
