package com.yash.tddAssignments;

public class Employee {
	
	String firstName;
	String lastName;
	String company;
	String role;
	
	
	public Employee(String firstName, String lastName, String company, String role) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.company = company;
		this.role = role;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	

}
