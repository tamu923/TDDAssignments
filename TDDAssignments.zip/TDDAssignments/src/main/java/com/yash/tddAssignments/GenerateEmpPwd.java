package com.yash.tddAssignments;

public class GenerateEmpPwd {

	String genaratePassword(Employee emp) {
		
		String password="";
		if(emp.getFirstName().length()>2 && emp.getLastName().length()>2&&
			 emp.getCompany().length()>2 &&  emp.getRole().length()>2) {
			 password = emp.getFirstName().substring(0, 2) + emp.getLastName().substring(0, 2)
					+ emp.getCompany().substring(0, 2) + emp.getRole().substring(0, 2);
		}
		

		return password;
	}

}
