package com.yash.tddAssignments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TddAssignmentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TddAssignmentsApplication.class, args);
		
	}
}
