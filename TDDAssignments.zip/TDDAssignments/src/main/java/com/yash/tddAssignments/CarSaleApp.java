package com.yash.tddAssignments;

import java.util.ArrayList;

public class CarSaleApp {
	
	public int getSoldCar(ArrayList<Car> carList) {
		
		Integer soldCarCount = carList.stream()
				  .map(x -> x.getCarSoldYN())
				  .reduce(0, Integer::sum);
		
			return soldCarCount;
			 
		
	}
		
		
	
	
	
	
	

}
