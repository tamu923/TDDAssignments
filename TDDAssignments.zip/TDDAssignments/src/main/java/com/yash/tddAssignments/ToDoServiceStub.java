package com.yash.tddAssignments;

import java.util.Arrays;
import java.util.List;

public class ToDoServiceStub implements ToDoService{

	 public List<String> getTodos(String user) {  
	      
		    return Arrays.asList("Core Java ", "Spring Core ", " Hibernate ", " Spring MVC ");  
		    }  
}
