package com.yash.tddAssignments;

public class StringDemo {

	private String input;

	public String getInput() {
		return input;
	}

	public void setInput(String input) {
		this.input = input;
	}
	
	public String getRequiredData(String input) {
		if(input!=null&& !input.isEmpty())
		{
			return input;	
		}else {
			return "There is no string";
		}
	
	}
}
