package com.yash.tddAssignments;

public class Car {

	int speed;
	String carOwner;
	String carType;
	int carSoldYN;
	
	
	
	
	public Car(int speed, String carOwner, String carType, int carSoldYN) {
		super();
		this.speed = speed;
		this.carOwner = carOwner;
		this.carType = carType;
		this.carSoldYN = carSoldYN;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public String getCarOwner() {
		return carOwner;
	}
	public void setCarOwner(String carOwner) {
		this.carOwner = carOwner;
	}
	public String getCarType() {
		return carType;
	}
	public void setCarType(String carType) {
		this.carType = carType;
	}
	public int getCarSoldYN() {
		return carSoldYN;
	}
	public void setCarSoldYN(int carSoldYN) {
		this.carSoldYN = carSoldYN;
	}
	
	
	
}
