package com.yash.tddAssignments;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class CarSaleAppTest {

	
	CarSaleApp sut= new CarSaleApp();
	
	@Test
	@DisplayName("Test Case")
	void testCarsSale() {
		Car car1= new Car(120,"Diwan","Sedan",1);
		Car car2= new Car(60,"Diwan","Commercial",1);
		ArrayList<Car> carList= new ArrayList<>();
		carList.add(car1);
		carList.add(car2);
		
		assertEquals(2, sut.getSoldCar(carList));
	}
	
	@Test
	void testCarsSale2() {
		Car car1= new Car(120,"Diwan","Sedan",0);
		Car car2= new Car(60,"Diwan","Commercial",0);
		ArrayList<Car> carList= new ArrayList<>();
		carList.add(car1);
		carList.add(car2);
		
		assertEquals(0, sut.getSoldCar(carList));
	}

}
