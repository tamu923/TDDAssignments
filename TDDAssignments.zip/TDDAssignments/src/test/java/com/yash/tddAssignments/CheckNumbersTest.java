package com.yash.tddAssignments;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.yash.tddAssignments.CheckNumbers;

public class CheckNumbersTest {

	
	CheckNumbers checkNum= new CheckNumbers();
	
	
	@Test
	public void testDigitMultiplication01() {
		
		assertEquals("6", checkNum.checkDigitMultiplication(23));
		
	}
	
	
	@Test
	public void testDigitMultiplication02() {
		
		assertEquals("0", checkNum.checkDigitMultiplication(0));
		
	}
	
	
	
}
