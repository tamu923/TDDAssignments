package com.yash.tddAssignments;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class GenerateEmpPwdTest {

	GenerateEmpPwd sut= new GenerateEmpPwd();
	
	Employee emp= new Employee("pankaj", "sharma", "yash", "trainer");
	
	
	@Test
	void testEmpPassword() {
		assertEquals("pashyatr", sut.genaratePassword(emp));
	}
	
	
	@Test
	void generatePasswordTes02() {
		emp.setCompany("");
		assertEquals("", sut.genaratePassword(emp));
	}

}
