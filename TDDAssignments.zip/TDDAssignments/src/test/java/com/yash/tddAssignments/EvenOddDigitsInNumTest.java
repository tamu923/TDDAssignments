package com.yash.tddAssignments;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class EvenOddDigitsInNumTest {
	
	EvenOddDigitsInNum sut= new EvenOddDigitsInNum();
	
	
	@Test
	public void countEvenOdTest1() {
		assertEquals("3 5", sut.countEvenOdd(57832149));
		
	}
	
	
	@Test
	public void countEvenOdTest2() {
		assertEquals("0 0", sut.countEvenOdd(0));
		
	}

}
