package com.yash.tddAssignments;

public class Document {

	
	String title;
	String filePath;
	
	
	public Document(String title, String filePath) {
		super();
		this.title = title;
		this.filePath = filePath;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	
	
	
}
