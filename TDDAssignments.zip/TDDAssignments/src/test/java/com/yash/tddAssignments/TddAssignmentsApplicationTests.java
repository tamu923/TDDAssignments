package com.yash.tddAssignments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TddAssignmentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
