package com.yash.tddAssignments;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class StringDemoTest {

	StringDemo sut= new StringDemo();
	
	@Test
	void testString() {
		assertEquals("Mockito", sut.getRequiredData("Mockito"));
	}
	
	@Test
	void testString2() {
		assertEquals("There is no string", sut.getRequiredData(""));
	}

}
