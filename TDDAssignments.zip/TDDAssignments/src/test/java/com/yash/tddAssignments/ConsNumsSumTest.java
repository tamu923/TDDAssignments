package com.yash.tddAssignments;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class ConsNumsSumTest {

	ConsNumsSum sut= new ConsNumsSum();
	
	@Test
	public void consecutiveNumsSumTest01() {
	
		assertEquals(55, sut.consecutiveNumsSum(10));
	}
	
	@Test
	public void consecutiveNumsSumTest02() {
	
		assertEquals(0, sut.consecutiveNumsSum(0));
	}
	
	
	@Test
	public void consecutiveNumsSumTest03() {
	
		assertEquals(15, sut.consecutiveNumsSum(9));
	}
	
	
}
